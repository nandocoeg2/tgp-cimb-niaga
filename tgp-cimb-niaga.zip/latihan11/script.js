const car = {
  nama: "Ferrari",
  model: 50,
  color: "red",
  getName: () => {
    return car.nama;
  },
};

console.log(car.getName());
