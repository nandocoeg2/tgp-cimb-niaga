[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/pp-oZlBg)
# Live-Code-1 Starter Program WDP
## RULES
1. Kerjakan secara individu. Segala bentuk kecurangan (mencontek, diskusi, ataupun menggunakan bantuan AI seperti ChatGPT) akan menyebabkan skor live code ini 0.
2. Waktu pengerjaan: **60 menit** 
3. Membuka referensi eksternal seperti Google, StackOverflow, dan MDN diperbolehkan.
4. Dilarang membuka repository di organisasi tugas, baik pada organisasi batch sendiri ataupun batch lain, baik branch sendiri maupun branch orang lain (**setelah melakukan clone, close tab GitHub pada web browser kalian**).
5. Lakukan `git push origin <WDP-Livecode1-github_name>` **hanya jika waktu Live Code telah dinyatakan usai**.
6. Silakan lihat requirement livecode pada file pdf `Requirement LC 1.pdf`
6. Jika terdapat skeleton code pada soal, Anda diperbolehkan untuk menyalin kode tersebut ke jawaban Anda untuk menghemat waktu.